;; Mars Rover Sample Collection - Domain
;; Requirements: only :strips and :typing (no negative preconditions, no numeric fluents)
(define (domain mars-rover)
  (:requirements :strips :typing)

  (:types
    location rover bay equipment rock
  )

  (:predicates
    (rover-at ?r - rover ?l - location)          ; rover is at location
    (connected ?from - location ?to - location)  ; directed edge: rover may move from -> to
    (rock-at ?k - rock ?l - location)            ; rock lies on the ground at location
    (equipment-at ?e - equipment ?l - location)  ; drill lies on the ground at location
    (has-equipment ?r - rover ?e - equipment)    ; rover is carrying the drill (kept forever)
    (bay-of ?b - bay ?r - rover)                 ; bay belongs to rover
    (bay-empty ?b - bay)                         ; bay holds nothing
    (rock-in-bay ?k - rock ?b - bay)             ; rock is stored in bay
    (soft ?k - rock)                             ; soft rock: no drill needed
    (hard ?k - rock)                             ; hard rock: drill needed
  )

  ;; Move along a directed edge (two-way routes are encoded as two edges)
  (:action move
    :parameters (?r - rover ?from - location ?to - location)
    :precondition (and (rover-at ?r ?from) (connected ?from ?to))
    :effect (and (rover-at ?r ?to) (not (rover-at ?r ?from)))
  )

  ;; Pick up the drill at the current location (kept for the rest of the mission)
  (:action pick-drill
    :parameters (?r - rover ?e - equipment ?l - location)
    :precondition (and (rover-at ?r ?l) (equipment-at ?e ?l))
    :effect (and (has-equipment ?r ?e) (not (equipment-at ?e ?l)))
  )

  ;; Collect a soft rock into an empty bay
  (:action collect-soft
    :parameters (?r - rover ?k - rock ?l - location ?b - bay)
    :precondition (and (rover-at ?r ?l) (rock-at ?k ?l) (soft ?k)
                       (bay-of ?b ?r) (bay-empty ?b))
    :effect (and (rock-in-bay ?k ?b) (not (rock-at ?k ?l)) (not (bay-empty ?b)))
  )

  ;; Collect a hard rock into an empty bay: requires the drill
  (:action collect-hard
    :parameters (?r - rover ?k - rock ?l - location ?b - bay ?e - equipment)
    :precondition (and (rover-at ?r ?l) (rock-at ?k ?l) (hard ?k)
                       (bay-of ?b ?r) (bay-empty ?b) (has-equipment ?r ?e))
    :effect (and (rock-in-bay ?k ?b) (not (rock-at ?k ?l)) (not (bay-empty ?b)))
  )

  ;; Deposit a rock from a bay at the rover's current location
  (:action deposit
    :parameters (?r - rover ?k - rock ?l - location ?b - bay)
    :precondition (and (rover-at ?r ?l) (bay-of ?b ?r) (rock-in-bay ?k ?b))
    :effect (and (rock-at ?k ?l) (bay-empty ?b) (not (rock-in-bay ?k ?b)))
  )
)

/*
Problem 3: Royal Archive Access Verification
Using Resolution Refutation

Goal: Prove trusted(mira) by deriving the empty clause [].
*/

% Step 1: Predicate Logic Representation
%
% Rule 1: (archivist(X) AND verifies(X,R)) -> trusted(X).
% Rule 2: (trusted(X) AND has_access(X,R) AND sealed(R))
%         -> permitted_to_inspect(X,R).
% Rule 3: (inspects(X,R) AND finds_hidden_mark(X,R)) -> verifies(X,R).
% Rule 4: stored_in_archive(R) -> sealed(R).
%
% Facts:
% stored_in_archive(scroll_7).
% has_access(mira, scroll_7).
% inspects(mira, scroll_7).
% finds_hidden_mark(mira, scroll_7).
% archivist(mira).
%
% Predicates describe people, records, access, and actions.
% Constants: mira, scroll_7
% Variables: X (person), R (record)

% Step 2: Negation of the Goal
% Goal: trusted(mira).
% Negated goal: not trusted(mira).

% Step 3: Implication Removal
% P -> Q is equivalent to not(P) OR Q.
%
% C1: not(archivist(X)) OR not(verifies(X,R)) OR trusted(X)
% C2: not(trusted(X)) OR not(has_access(X,R)) OR not(sealed(R))
%     OR permitted_to_inspect(X,R)
% C3: not(inspects(X,R)) OR not(finds_hidden_mark(X,R))
%     OR verifies(X,R)
% C4: not(stored_in_archive(R)) OR sealed(R)

% Step 4: Negation Movement
% Negations apply to individual predicates.
% No De Morgan transformation is needed.

% Step 5: Standardization Apart
% Each call to kb_clause/2 creates fresh variables for each clause.

% Step 6: Skolemization
% There are no existential quantifiers, so Skolemization is unnecessary.
% Universal quantifiers are implicit in the clauses.

% Step 7: CNF Clauses
% pos(Atom) represents a positive literal.
% neg(Atom) represents a negative literal.

kb_clause(c1, [
    neg(archivist(X)),
    neg(verifies(X,_R)),
    pos(trusted(X))
]).

kb_clause(c2, [
    neg(trusted(X)),
    neg(has_access(X,R)),
    neg(sealed(R)),
    pos(permitted_to_inspect(X,R))
]).

kb_clause(c3, [
    neg(inspects(X,R)),
    neg(finds_hidden_mark(X,R)),
    pos(verifies(X,R))
]).

kb_clause(c4, [
    neg(stored_in_archive(R)),
    pos(sealed(R))
]).

kb_clause(c5, [pos(stored_in_archive(scroll_7))]).
kb_clause(c6, [pos(has_access(mira, scroll_7))]).
kb_clause(c7, [pos(inspects(mira, scroll_7))]).
kb_clause(c8, [pos(finds_hidden_mark(mira, scroll_7))]).
kb_clause(c9, [pos(archivist(mira))]).
kb_clause(c10, [neg(trusted(mira))]).

% Step 8: Resolution Implementation and Execution

complementary(pos(A), neg(B)) :-
    A = B.
complementary(neg(A), pos(B)) :-
    A = B.

resolve(C1, C2, Resolvent) :-
    select(L1, C1, Rest1),
    select(L2, C2, Rest2),
    complementary(L1, L2),
    append(Rest1, Rest2, Combined),
    sort(Combined, Resolvent).

show_kb_clause(Label, Clause) :-
    write(Label),
    write(' = '),
    write(Clause),
    nl.

main :-
    nl,
    writeln('Royal Archive: Resolution Refutation'),
    writeln('Step 1: Resolve C3 with C7'),

    kb_clause(c3, C3),
    kb_clause(c7, C7),
    resolve(C3, C7, R1),
    show_kb_clause('Resolvent 1', R1),
    nl,

    writeln('Step 2: Resolve Resolvent 1 with C8'),
    kb_clause(c8, C8),
    resolve(R1, C8, R2),
    writeln('Derived: verifies(mira,scroll_7)'),
    show_kb_clause('Resolvent 2', R2),
    nl,

    writeln('Step 3: Resolve C1 with C9'),
    kb_clause(c1, C1),
    kb_clause(c9, C9),
    resolve(C1, C9, R3),
    show_kb_clause('Resolvent 3', R3),
    nl,

    writeln('Step 4: Resolve Resolvent 3 with Resolvent 2'),
    resolve(R3, R2, R4),
    writeln('Substitution: X = mira, R = scroll_7'),
    writeln('Derived: trusted(mira)'),
    show_kb_clause('Resolvent 4', R4),
    nl,

    writeln('Step 5: Resolve Resolvent 4 with C10'),
    kb_clause(c10, C10),
    resolve(R4, C10, Empty),
    show_kb_clause('Resolvent 5', Empty),

    ( Empty == [] ->
        nl,
        writeln('SUCCESS: Empty clause [] derived.'),
        writeln('CONCLUSION: Mira is trusted.')
    ;
        nl,
        writeln('FAILURE: Empty clause was not derived.')
    ).

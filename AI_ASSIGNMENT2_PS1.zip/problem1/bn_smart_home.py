"""
Problem 1: Smart Home Energy Consumption Analysis using Bayesian Networks
Group Assignment 2 -- AI

Group members: <Parinitha Pulipati (B24CS037)>, <Varshitha Vadlamuru (B24ME050)>, <Thanmaie Nagineni (B24EC019)>, <Malraju Srinayana (B24CS024)>, <Badagoni Sri Sahasra (B24DS003)>

"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')
import itertools
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from pgmpy.models import DiscreteBayesianNetwork as BayesianNetwork
except ImportError:                                   # older pgmpy
    from pgmpy.models import BayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination
from pgmpy.estimators import MaximumLikelihoodEstimator, BayesianEstimator

SEED = 42
OUT = "results"
os.makedirs(OUT, exist_ok=True)


class Tee:
    def __init__(self, *files):
        self.files = files

    def write(self, s):
        for f in self.files:
            f.write(s)

    def flush(self):
        for f in self.files:
            f.flush()


_log = open(os.path.join(OUT, "output_log.txt"), "w", encoding="utf-8")
sys.stdout = Tee(sys.__stdout__, _log)

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 50)


def banner(t):
    print("\n" + "=" * 78 + f"\n{t}\n" + "=" * 78)


# PART A - EXPERT BAYESIAN NETWORK

banner("PART A: EXPERT BAYESIAN NETWORK")

STATES = {
    "Weather":     ["Hot", "Mild", "Cold"],
    "DayType":     ["Weekday", "Weekend"],
    "Occupancy":   ["High", "Low"],
    "AC":          ["On", "Off"],
    "ApplianceLoad": ["Heavy", "Light"],
    "Energy":      ["High", "Low"],
}
EDGES = [("Weather", "AC"), ("DayType", "Occupancy"), ("Occupancy", "AC"),
         ("Occupancy", "ApplianceLoad"), ("AC", "Energy"), ("ApplianceLoad", "Energy")]
PARENTS = {"Weather": [], "DayType": [], "Occupancy": ["DayType"],
           "AC": ["Weather", "Occupancy"], "ApplianceLoad": ["Occupancy"],
           "Energy": ["AC", "ApplianceLoad"]}
TOPO = ["Weather", "DayType", "Occupancy", "AC", "ApplianceLoad", "Energy"]


P_TRUE = {
    "Weather":   {(): 0.0},   # handled separately (3 states)
    "DayType":   {(): 0.70},  # P(Weekday)
    "Occupancy": {("Weekday",): 0.45, ("Weekend",): 0.80},                 # P(High)
    "AC":        {("Hot", "High"): 0.90, ("Hot", "Low"): 0.60,
                  ("Mild", "High"): 0.40, ("Mild", "Low"): 0.15,
                  ("Cold", "High"): 0.10, ("Cold", "Low"): 0.05},          # P(On)
    "ApplianceLoad": {("High",): 0.75, ("Low",): 0.35},                    # P(Heavy)
    "Energy":    {("On", "Heavy"): 0.92, ("On", "Light"): 0.68,
                  ("Off", "Heavy"): 0.55, ("Off", "Light"): 0.12},         # P(High)
}
WEATHER_PRIOR = [0.50, 0.30, 0.20]


def make_cpd(var):
    """Build a TabularCPD for `var` (columns ordered as itertools.product of parents)."""
    st = STATES[var]
    par = PARENTS[var]
    if var == "Weather":
        return TabularCPD("Weather", 3, [[p] for p in WEATHER_PRIOR],
                          state_names={"Weather": st})
    configs = list(itertools.product(*[STATES[p] for p in par]))
    p_first = [P_TRUE[var][c if par else ()] for c in configs]
    values = [p_first, [1 - p for p in p_first]]
    return TabularCPD(var, 2, values,
                      evidence=par or None,
                      evidence_card=[len(STATES[p]) for p in par] or None,
                      state_names={v: STATES[v] for v in [var] + par})


def build_expert():
    m = BayesianNetwork(EDGES)
    m.add_cpds(*[make_cpd(v) for v in TOPO])
    return m


expert = build_expert()


print("\n[A2] Programmatic CPD verification")
for v in TOPO:
    cpd = expert.get_cpds(v)
    col_sums = cpd.values.reshape(cpd.variable_card, -1).sum(axis=0)
    ok = np.allclose(col_sums, 1.0)
    print(f"  CPD of {v:14s}: every parent configuration sums to 1 -> {ok}")
    assert ok
print(f"  model.check_model() -> {expert.check_model()}")
print("\nExpert CPD for AC:")
print(expert.get_cpds("AC"))


G = nx.DiGraph(EDGES)
pos = {"Weather": (0, 2), "DayType": (4, 2), "Occupancy": (4, 1),
       "AC": (1.5, 0), "ApplianceLoad": (5.5, 0), "Energy": (3.5, -1)}
plt.figure(figsize=(8, 6))
nx.draw(G, pos, with_labels=True, node_color="#cfe8ff", node_size=3800,
        font_size=9, font_weight="bold", arrowsize=25, edgecolors="black")
plt.title("Expert Bayesian Network - Smart Home Energy")
plt.savefig(os.path.join(OUT, "bn_structure.png"), dpi=150, bbox_inches="tight")
plt.close()
print("\n[A3] Network drawing saved to results/bn_structure.png")


QUERIES = {   # name: (description, evidence dict)
    "Q1": ("P(E=High)", {}),
    "Q2": ("P(E=High | W=Hot)", {"Weather": "Hot"}),
    "Q3": ("P(E=High | D=Weekend)", {"DayType": "Weekend"}),
    "Q4": ("P(E=High | W=Cold, O=High)", {"Weather": "Cold", "Occupancy": "High"}),
    "Q5": ("P(W=Hot | E=High)", {"Energy": "High"}),
    "Q6": ("P(AC=On | E=High)", {"Energy": "High"}),
    "Q7": ("P(AC=On | E=High, L=Heavy)", {"Energy": "High", "ApplianceLoad": "Heavy"}),
}
TARGET = {"Q1": ("Energy", "High"), "Q2": ("Energy", "High"), "Q3": ("Energy", "High"),
          "Q4": ("Energy", "High"), "Q5": ("Weather", "Hot"), "Q6": ("AC", "On"),
          "Q7": ("AC", "On")}


def run_queries(model):
    inf = VariableElimination(model)
    res = {}
    for q, (_, ev) in QUERIES.items():
        var, val = TARGET[q]
        res[q] = inf.query([var], evidence=ev or None, show_progress=False).get_value(**{var: val})
    return res


def prob(model, var, val, evidence=None):
    inf = VariableElimination(model)
    return inf.query([var], evidence=evidence or None, show_progress=False).get_value(**{var: val})


expert_res = run_queries(expert)
print("\n[A4] Expert-model query results")
for q, (d, _) in QUERIES.items():
    print(f"  {q}: {d:32s} = {expert_res[q]:.6f}")


q6, q7 = expert_res["Q6"], expert_res["Q7"]
print("\n[A5] Explaining away")
print(f"  Q6 = P(AC=On | E=High)                  = {q6:.4f}")
print(f"  Q7 = P(AC=On | E=High, Load=Heavy)      = {q7:.4f}")
print(f"  change Q7 - Q6 = {q7 - q6:+.4f}  -> belief in AC=On {'drops' if q7 < q6 else 'rises'}")
print("""  Explanation: AC and ApplianceLoad are two causes of Energy
  (a collider  AC -> Energy <- ApplianceLoad).  Observing E=High makes both causes
  more likely.  Learning additionally that Load=Heavy already provides one sufficient
  explanation for the high consumption, so the need for the other cause (AC=On) is
  reduced and its posterior goes DOWN.  This is 'explaining away'.
  (The drop is modest because Occupancy is a common parent that keeps AC and Load
  weakly positively correlated, and AC=On is still the more common state.)""")


print("\n[A6] Q1 by hand -- marginalising the chain  D -> O -> {A, L} -> E")
pD = {"Weekday": 0.70, "Weekend": 0.30}
pW = dict(zip(STATES["Weather"], WEATHER_PRIOR))
pO_H = {"Weekday": 0.45, "Weekend": 0.80}
pL_H = {"High": 0.75, "Low": 0.35}
pA_On = {(w, o): P_TRUE["AC"][(w, o)] for w in STATES["Weather"] for o in STATES["Occupancy"]}
pE_H = P_TRUE["Energy"]

pO = {"High": sum(pD[d] * pO_H[d] for d in pD)}
pO["Low"] = 1 - pO["High"]
print(f"  Step 1  P(O=High) = 0.70*0.45 + 0.30*0.80 = {pO['High']:.4f};  P(O=Low) = {pO['Low']:.4f}")

pAon_O = {}
for o in ["High", "Low"]:
    terms = [f"{pW[w]:.2f}*{pA_On[(w, o)]:.2f}" for w in pW]
    pAon_O[o] = sum(pW[w] * pA_On[(w, o)] for w in pW)
    print(f"  Step 2  P(AC=On | O={o:4s}) = {' + '.join(terms)} = {pAon_O[o]:.4f}")

pE_O = {}
for o in ["High", "Low"]:
    pa = pAon_O[o]
    pl = pL_H[o]
    parts = []
    tot = 0
    for a, pa_ in (("On", pa), ("Off", 1 - pa)):
        for l, pl_ in (("Heavy", pl), ("Light", 1 - pl)):
            t = pa_ * pl_ * pE_H[(a, l)]
            tot += t
            parts.append(f"P(A={a})P(L={l})P(E=H|{a},{l}) = {pa_:.4f}*{pl_:.2f}*{pE_H[(a, l)]:.2f} = {t:.6f}")
    pE_O[o] = tot
    print(f"  Step 3  P(E=High | O={o}) :")
    for p in parts:
        print(f"            {p}")
    print(f"            sum = {tot:.6f}")

q1_hand = sum(pO[o] * pE_O[o] for o in pO)
print(f"  Step 4  P(E=High) = P(O=H)*P(E=H|O=H) + P(O=L)*P(E=H|O=L)")
print(f"                    = {pO['High']:.3f}*{pE_O['High']:.6f} + {pO['Low']:.3f}*{pE_O['Low']:.6f}")
print(f"                    = {q1_hand:.6f}")
print(f"  Code (VariableElimination) Q1 = {expert_res['Q1']:.6f}  -> match: {np.isclose(q1_hand, expert_res['Q1'])}")


def joint(assign):
    p = pW[assign["Weather"]] * pD[assign["DayType"]]
    p *= pO_H[assign["DayType"]] if assign["Occupancy"] == "High" else 1 - pO_H[assign["DayType"]]
    pa = pA_On[(assign["Weather"], assign["Occupancy"])]
    p *= pa if assign["AC"] == "On" else 1 - pa
    pl = pL_H[assign["Occupancy"]]
    p *= pl if assign["ApplianceLoad"] == "Heavy" else 1 - pl
    pe = pE_H[(assign["AC"], assign["ApplianceLoad"])]
    p *= pe if assign["Energy"] == "High" else 1 - pe
    return p


q1_joint = sum(joint(dict(zip(TOPO, c))) for c in itertools.product(*[STATES[v] for v in TOPO])
               if c[TOPO.index("Energy")] == "High")
print(f"  Full-joint enumeration (3*2*2*2*2 = 48 rows, E=High) -> {q1_joint:.6f}")


banner("PART B: CONDITIONAL INDEPENDENCE ANALYSIS")


def d_separated(x, y, z):
    z = set(z)
    if hasattr(nx, "is_d_separator"):
        return nx.is_d_separator(G, {x}, {y}, z)
    return nx.d_separated(G, {x}, {y}, z)


tests = [
    ("1. Weather _|_ DayType", "Weather", "DayType", []),
    ("2. Weather _|_ DayType | Energy", "Weather", "DayType", ["Energy"]),
    ("3. Weather _|_ ApplianceLoad | Occupancy", "Weather", "ApplianceLoad", ["Occupancy"]),
]
for name, x, y, z in tests:
    print(f"  {name:45s} -> d-separated (independent): {d_separated(x, y, z)}")

print("""
  Path-based justification
  1. Weather _|_ DayType  : HOLDS.
       W -> AC <- O <- D         : collider at AC (AC and its descendant Energy unobserved) -> blocked
       W -> AC -> E <- L <- O <- D : collider at Energy, unobserved -> blocked
  2. Weather _|_ DayType | E : DOES NOT HOLD.
       W -> AC -> E <- L <- O <- D : AC (chain), L (chain), O (chain) are unobserved non-colliders,
       and the collider E is observed -> path is OPEN.  (Also W -> AC <- O <- D opens, since
       AC's descendant E is observed.)  Conditioning on a collider couples W and D.
  3. Weather _|_ ApplianceLoad | O : HOLDS.
       W -> AC <- O -> L  : O is an observed fork (non-collider) -> blocked (AC collider also unobserved)
       W -> AC -> E <- L  : collider E unobserved -> blocked""")

print("  Numerical verification")
a1 = prob(expert, "Weather", "Hot")
b1 = prob(expert, "Weather", "Hot", {"DayType": "Weekend"})
print(f"  (1) P(W=Hot) = {a1:.6f}   vs   P(W=Hot | D=Weekend) = {b1:.6f}   -> equal: {np.isclose(a1, b1)}")
a2 = prob(expert, "Weather", "Hot", {"Energy": "High"})
b2 = prob(expert, "Weather", "Hot", {"Energy": "High", "DayType": "Weekend"})
print(f"  (2) P(W=Hot | E=High) = {a2:.6f}   vs   P(W=Hot | E=High, D=Weekend) = {b2:.6f}   -> equal: {np.isclose(a2, b2)}")
a3 = prob(expert, "Weather", "Hot", {"Occupancy": "High"})
b3 = prob(expert, "Weather", "Hot", {"Occupancy": "High", "ApplianceLoad": "Heavy"})
print(f"  (3) P(W=Hot | O=High) = {a3:.6f}   vs   P(W=Hot | O=High, L=Heavy) = {b3:.6f}   -> equal: {np.isclose(a3, b3)}")


banner(f"PART C: SYNTHETIC DATA GENERATION (ancestral sampling, seed = {SEED})")


def cond_dist(var, parent_vals):
    """Return list of probabilities over STATES[var] for given parent configuration."""
    if var == "Weather":
        return WEATHER_PRIOR
    if var == "DayType":
        p = P_TRUE["DayType"][()]
    else:
        p = P_TRUE[var][tuple(parent_vals)]
    return [p, 1 - p]


def ancestral_sample(n, seed):
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n):
        s = {}
        for v in TOPO:                                   # topological order
            probs = cond_dist(v, [s[p] for p in PARENTS[v]])
            s[v] = STATES[v][rng.choice(len(probs), p=probs)]
        rows.append(s)
    return pd.DataFrame(rows, columns=TOPO)


SIZES = [500, 5000, 20000]
datasets = {}
for n in SIZES:
    df = ancestral_sample(n, SEED)
    datasets[n] = df
    df.to_csv(os.path.join(OUT, f"data_{n}.csv"), index=False)
    print(f"\n--- Dataset n = {n} ---")
    freq = df["Weather"].value_counts(normalize=True).reindex(STATES["Weather"])
    print("Empirical Weather frequencies (true: Hot .50, Mild .30, Cold .20):")
    print(freq.round(4).to_string())
    ct = pd.crosstab(df["Weather"], df["Occupancy"]).reindex(index=STATES["Weather"],
                                                              columns=STATES["Occupancy"])
    print("Counts per (Weather, Occupancy):")
    print(ct.to_string())


banner("PART D: LEARNING FROM DATA (MLE vs BDeu, equivalent sample size = 10)")


def learn(df, method):
    m = BayesianNetwork(EDGES)
    if method == "MLE":
        est = MaximumLikelihoodEstimator(m, df, state_names=STATES)
        cpds = est.get_parameters()
    else:
        est = BayesianEstimator(m, df, state_names=STATES)
        cpds = est.get_parameters(prior_type="BDeu", equivalent_sample_size=10)
    m.add_cpds(*cpds)
    m.check_model()
    return m


def ac_table(model):
    rows = {}
    for w in STATES["Weather"]:
        for o in STATES["Occupancy"]:
            rows[(w, o)] = model.get_cpds("AC").get_value(AC="On", Weather=w, Occupancy=o)
    return pd.Series(rows)


learned, results = {}, {}
for n in SIZES:
    learned[n] = {"MLE": learn(datasets[n], "MLE"), "Bayes": learn(datasets[n], "Bayes")}
    results[n] = {"Expert": expert_res,
                  "MLE": run_queries(learned[n]["MLE"]),
                  "Bayes": run_queries(learned[n]["Bayes"])}

    t = pd.DataFrame({"Expert": ac_table(expert),
                      "MLE": ac_table(learned[n]["MLE"]),
                      "BDeu(ESS=10)": ac_table(learned[n]["Bayes"])})
    t.index = [f"W={w}, O={o}" for w, o in t.index]
    t.index.name = "P(AC=On | ...)"
    t["|MLE-Exp|"] = (t["MLE"] - t["Expert"]).abs()
    t["|BDeu-Exp|"] = (t["BDeu(ESS=10)"] - t["Expert"]).abs()
    print(f"\n--- Learned vs expert CPT for AC, n = {n} ---")
    print(t.round(4).to_string())
    t.round(6).to_csv(os.path.join(OUT, f"cpt_AC_{n}.csv"))

banner("PART E: COMPARATIVE ANALYSIS")
mean_err = {"MLE": [], "Bayes": []}
worst_q = {}
for n in SIZES:
    r = results[n]
    tab = pd.DataFrame({
        "Description": [QUERIES[q][0] for q in QUERIES],
        "Expert": [r["Expert"][q] for q in QUERIES],
        "MLE": [r["MLE"][q] for q in QUERIES],
        "Bayesian": [r["Bayes"][q] for q in QUERIES]}, index=list(QUERIES))
    tab["|Diff| MLE"] = (tab["MLE"] - tab["Expert"]).abs()
    tab["|Diff| Bayesian"] = (tab["Bayesian"] - tab["Expert"]).abs()
    tab.index.name = "Query"
    print(f"\n--- Dataset size n = {n} ---")
    print(tab.round(4).to_string())
    print(f"  Mean |Diff|  MLE = {tab['|Diff| MLE'].mean():.5f}    Bayesian = {tab['|Diff| Bayesian'].mean():.5f}")
    tab.round(6).to_csv(os.path.join(OUT, f"comparison_{n}.csv"))
    mean_err["MLE"].append(tab["|Diff| MLE"].mean())
    mean_err["Bayes"].append(tab["|Diff| Bayesian"].mean())
    worst_q[n] = (tab["|Diff| MLE"].idxmax(), tab["|Diff| Bayesian"].idxmax())

# E.1 plot
plt.figure(figsize=(7, 4.5))
plt.plot(SIZES, mean_err["MLE"], "o-", label="MLE")
plt.plot(SIZES, mean_err["Bayes"], "s-", label="Bayesian (BDeu, ESS=10)")
plt.xscale("log")
plt.xlabel("Dataset size (log scale)")
plt.ylabel("Mean absolute difference over Q1-Q7")
plt.title("Learning error vs dataset size")
plt.grid(alpha=.3)
plt.legend()
plt.savefig(os.path.join(OUT, "mean_abs_diff_vs_size.png"), dpi=150, bbox_inches="tight")
plt.close()
print("\n[E1] Plot saved to results/mean_abs_diff_vs_size.png")


df500 = datasets[500]
print(f"\n[E2] Largest error at n=500: MLE -> {worst_q[500][0]}, Bayesian -> {worst_q[500][1]}")
print("  How often does the evidence of each conditional query occur in the 500-sample data?")
for q, (d, ev) in QUERIES.items():
    mask = np.ones(len(df500), bool)
    for k, v in ev.items():
        mask &= (df500[k] == v).to_numpy()
    print(f"    {q}: evidence {str(ev):55s} -> {mask.sum():4d} rows")
cold_high = ((df500.Weather == "Cold") & (df500.Occupancy == "High")).sum()
print(f"  (W=Cold, O=High) rows = {cold_high};  and AC CPT cell (Cold, High) is estimated from only these rows.")


print("""
[E3] Discussion -- which estimator is better for small data?
  MLE sets each CPT entry to the raw relative frequency, so rare parent configurations
  (e.g. Weather=Cold & Occupancy=High, only ~50 of 500 rows, or Cold & Low, ~45 rows) are
  estimated from very few rows and can land far from the truth (or be 0/1 if a configuration
  never appears -> zero-probability events).  Bayesian estimation with the BDeu prior adds
  pseudo-counts ESS / (|parent configs| * |states|) to every cell, which shrinks sparse
  estimates toward a uniform distribution, lowers variance and never produces exact 0/1.
  The price is a small bias toward uniform when the true CPT is far from uniform (e.g.
  P(AC=On|Cold,Low)=0.05).  So the Bayesian estimator is usually (but not always, on a single
  random draw) more stable for small samples; as n grows the pseudo-counts are swamped by
  the data and the two estimators converge to each other and to the expert CPTs.
  Check the numeric tables above for the actual comparison on this seed.""")

print("\nDone.  All figures and CSV tables are in the 'results/' folder.")
